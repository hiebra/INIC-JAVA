package org.example.api.vehiculos;

public enum TipoVehiculo {
	COCHE, MOTOCICLETA, BARCO
}
