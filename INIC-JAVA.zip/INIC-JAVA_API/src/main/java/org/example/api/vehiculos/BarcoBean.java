package org.example.api.vehiculos;

public interface BarcoBean extends VehiculoBean {

	boolean getTieneVela();
	
}
