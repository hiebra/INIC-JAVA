package org.example.api.vehiculos;

public interface VehiculoBean {

	String getNombre();
	
}
