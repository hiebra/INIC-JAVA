package org.example.cualificador.primero;

class MiSegundaClase {

	static {
		System.out.println("Hello, World!");
	}

	public static void main(String[] args) {
		System.out.println("Ya he saludado");
	}

}
